Powertrain Control Benchmark Model
Toyota Technial Center
2014

The experiments are done using S-TaLiRo 1.51 Beta and 64 bit Matlab 2013b under Windows 7 64 bit operation system.

Please follow the following steps to set up the working environment:

1. Download the S-TaLiRo 1.51 Beta from 

https://sites.google.com/a/asu.edu/s-taliro/s-taliro/download

2. Unzip the downloaded file, open Matlab, and navigate to the unzipped folder

3. Install S-TaLiRo 1.51 Beta by running the following command in Matlab command window:

>> setup_staliro

4. Navigate to the benchmark folder, open the interested Model folder, such as Model1. Run the following command in Matlab command window:

>> PropertyCheck

5. Choose the requirement number and run the experiment. 

