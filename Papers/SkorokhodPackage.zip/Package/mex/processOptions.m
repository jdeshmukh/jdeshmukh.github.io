%% Disclaimer
% Copyright (c) 2014, Toyota Technical Center
% All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted for non-commercial use provided that
% the following conditions are met:
%
%     * Redistributions of source code must retain the above copyright
%       notice, this list of conditions and the following disclaimer.
%     * Redistributions in binary form must reproduce the above copyright
%       notice, this list of conditions and the following disclaimer in
%       the documentation and/or other materials provided with the distribution
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
% Author: Jyotirmoy V. Deshmukh, Toyota Technical Center

function [flag, options] = processOptions(options,u1,u2)
       if (~isfield(options, 'delta'))
           fprintf('Warning: Using default Skorokhod distance bound of 1.\n');
           options.delta = 1;
       end
       if (~isfield(options, 'timeScaleFactor') || ...
           ~isfield(options, 'scaleVector'))
           if (isempty(u1) || isempty(u2)) 
                flag = false;
                fprintf('Error: provided empty inputs, cannot continue!');
                return;
           end
        end
        if (~isfield(options, 'timeScaleFactor'))
           % scale time such that a delta perturbation in the time-scaled
           % signals corresponds to roughly 5% of the simualation time
           % horizon. Note that this is an arbitrary heuristic, and this 
           % quantity is better supplied by the designer.
           options.timeScaleFactor = options.delta/(u1(end,1)*0.05);          
           fprintf('Warning: Using default Time Scale Factor of (0.05*simulation horizon) = %d\n',options.timeScaleFactor);
       end
       if (~isfield(options, 'scaleVector'))
           signalRange = max(max(u1(:,2:end),u2(:,2:end)))-min(min(u1(:,2:end),u2(:,2:end)));
           zeroIndices = (signalRange == 0);
           m = max(u1(:,2:end));
           signalRange(zeroIndices) = m(zeroIndices);
           % scale all signals such that a delta perturbation in the scaled
           % signal corresponds to roughly 5% of the range of the given
           % signals. Note that this is a heuristic, and this quantity is
           % better supplied by the designer.
           options.scaleVector = options.delta./(0.05*signalRange);
           fprintf(['Warning: Using heuristic TRACE-DEPENDENT ' ...
                   'scale-vector of delta/(0.1* signal range) = ' ...
                   '%s\n',mat2str(options.scaleVector)]);
       end
       if (~isfield(options, 'window')) 
           scaledTime = u1(:,1)*options.timeScaleFactor;
           maxWindow = 1;
           for i=1:length(scaledTime)-1
             for j=i+1:length(scaledTime)
                if (scaledTime(j) - scaledTime(i) > 3*options.delta)
                   maxWindow = max(maxWindow, j-i);
                end
             end
           end
           options.window = maxWindow;
           fprintf('Warning: Using heuristic window size of %d.\n', options.window);
       end
       flag = true;
       if (~isfield(options, 'plot_skorokhod_flags'))
           options.plot_skorokhod_flags = 0;
       end
       if (~isfield(options, 'plot_traces'))
           options.plot_traces = 0;
       end
end
