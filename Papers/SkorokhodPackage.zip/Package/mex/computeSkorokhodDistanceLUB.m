%% Disclaimer
% Copyright (c) 2014, Toyota Technical Center
% All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted for non-commercial use provided that
% the following conditions are met:
%
%     * Redistributions of source code must retain the above copyright
%       notice, this list of conditions and the following disclaimer.
%     * Redistributions in binary form must reproduce the above copyright
%       notice, this list of conditions and the following disclaimer in
%       the documentation and/or other materials provided with the distribution
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
% Author: Jyotirmoy V. Deshmukh, Toyota Technical Center

function [delta, numComputations] = computeSkorokhodDistanceLUB(u1, u2, options)
    % This function computes the LUB on the Skorkohod distance between two
    % traces u1[0,T] and u2[0,T] by binary search on delta. It uses a static 
    % precision of 1e-3 or 0.01*(deltaHigh-deltaLow) (whichever is bigger) in 
    % the distance computation; i.e. binary search terminates after delta is
    % found to be in an interval of width equal to precision.  deltaHigh and 
    % deltaLow (bounds for the binary search) are computed using simple 
    % heuristics. deltaHigh is the maximum difference between values without 
    % any retiming. deltaLow is the maximum difference between trace values at 
    % time 0 and time T.
    numComputations = 0;
    if (~processArguments(u1, u2)) 
        fprintf('Error processing arguments.\n');
        delta = inf;
        return
    end
    [success, options] = processOptions(options,u1,u2);
    if (success ~= true) 
        fprintf('Error processing options.\n');
        delta = inf;
        return
    end
    for i=1:size(u1,1)
        scaled_u1(i,:) = u1(i,2:end) .* options.scaleVector(1,:); %#ok<AGROW>
        scaled_u2(i,:) = u2(i,2:end) .* options.scaleVector(1,:); %#ok<AGROW>
        udist(i,:) = norm(scaled_u1(i,:) - scaled_u2(i,:), 2);
    end
    
    deltaLow = norm(scaled_u1(1,:)-scaled_u2(1,:),2);
    fprintf('Delta Low = %d.\n', deltaLow);
    deltaLow = max(deltaLow, norm(scaled_u1(end,:)-scaled_u2(end,:),2));   
    deltaHigh = max(udist);
    fprintf('Delta High = %d.\n', deltaLow);
    options.delta = max(deltaLow - 0.1*deltaLow, 0);
    [status, result] = computeSkorokhodDistance(u1,u2,options);
    
    if (~any(status==false) && result(end)==true)
        fprintf('Error. Something is wrong, found Skorokhod distance bound lower than possible lower bound.\n');
        delta = -inf;
        return;
    end
    
    options.delta = deltaHigh + 0.1*deltaHigh;
    [status, result] = computeSkorokhodDistance(u1,u2,options);
    if (any(status==false) || result(end)==false)
        fprintf('Error. Something is wrong, found Skorokhod distance bound higher than possible upper bound.\n');
        delta = inf;
        return;
    end
    low = deltaLow; 
    high = deltaHigh;
    precision = max((high-low)/100,1e-3);
    while (high-low > precision)        
        delta = 0.5*(low + high);
        options.delta = delta;
        numComputations = numComputations + 1;
        [status, result] = computeSkorokhodDistance(u1,u2,options);
        if (any(status==false) || result(end)==false)
            low = delta;
        else
            high = delta;
        end
    end
    delta = high;
end
