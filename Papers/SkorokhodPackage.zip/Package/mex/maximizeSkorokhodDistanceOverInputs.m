%% Disclaimer
% Copyright (c) 2014, Toyota Technical Center
% All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted for non-commercial use provided that
% the following conditions are met:
%
%     * Redistributions of source code must retain the above copyright
%       notice, this list of conditions and the following disclaimer.
%     * Redistributions in binary form must reproduce the above copyright
%       notice, this list of conditions and the following disclaimer in
%       the documentation and/or other materials provided with the distribution
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
% Author: Jyotirmoy V. Deshmukh, Toyota Technical Center

function [modelInput, output1, output2, maxDist] = maximizeSkorokhodDistanceOverInputs(model1, model2, inputs, options)
    % check options and initialize anything not provided heuristically
    global skorokhodComputeTime;
    global numSimulations;
    numSimulations = 0;
    skorokhodComputeTime = 0;
    options = processToolOptions(options);
    
    optimizerOptions = optimset('MaxIter', options.maxIterations, ...
                       'MaxFunEvals', options.maxSimulations, ... 
                       'TolX', 1e-7, 'TolFun', 1e-7, 'TolCon', 1e-5);
    maxDist = -inf;
    beginOptimizer = tic;
    for k=1:options.numSeeds
        [point, lb, ub] = pickRandomInputs(inputs);
        costFunction = @(point) evaluate(point, model1, model2, inputs, options);
        [solv, dist, ~, out] = optimize(costFunction, point, lb, ub, [], [], [], [], [], ...
                          'superstrict', optimizerOptions);
        dist = -dist;
        if (dist > maxDist)
            sol = solv;
            maxDist = dist;
            output = out;
        end
    end
    toc(beginOptimizer);
    fprintf('------------------- Report -------------------\n');
    % Final reporting
    % fprintf('Algorithm used = %s.\n', output.algorithm);
    % fprintf('Num Fun Evals= %d.\n', output.funcCount);
    % fprintf('Num Iterations = %d.\n', output.iterations);
    fprintf('Num Simulations = %d.\n', numSimulations);
    fprintf('Skorokhod distance computation time = %d.\n', skorokhodComputeTime);
    modelInput = computeInputs(sol, inputs, options.simStep, options.timeHorizon);
    simopts = simget;
    [t1, ~, output1] = sim(model1, [0 options.timeHorizon], simopts, modelInput);
    output1 = [t1 output1];
    [t2, ~, output2] = sim(model2, [0 options.timeHorizon], simopts, modelInput);
    output2 = [t2 output2];
    fprintf('----------------------------------------------\n');
end

function [u1,u2] = computeOutputs(model1, model2, modelInput, timeHorizon)
    simopts1 = simget(model1);
    simopts2 = simget(model2);
    global numSimulations;
    numSimulations = numSimulations + 1;
    [t1, ~, y1] = sim(model1, [0 timeHorizon], simopts1, modelInput);
    [t2, ~, y2] = sim(model2, [0 timeHorizon], simopts2, modelInput);
    resample = ((length(t1)~=length(t2)) || ...
                ((length(t1) == length(t2)) && (any(t1-t2 > 1e-6))));
    if (resample)         
        if (t1(end) ~= t2(end))
            fprintf('Error, signals must end at the same time point.\n');
            return;
        end
        i = 1; j = 1;
        sampleTimes = [];
        while (i <= length(t1) || j <= length(t2))
            if (t1(i) < t2(j))
                sampleTimes = [sampleTimes t1(i)];
                i = i + 1;
            elseif (t1(i) > t2(j)) 
                sampleTimes = [sampleTimes t2(j)];
                j = j + 1;
            else 
                sampleTimes = [sampleTimes t1(i)];
                i = i + 1;
                j = j + 1;
            end
        end
        y1 = transpose(interp1(t1, y1, sampleTimes, 'linear'));
        y2 = transpose(interp1(t2, y2, sampleTimes, 'linear'));
        t1 = transpose(sampleTimes);
        t2 = t1;
    end
    u1 = [t1 y1];
    u2 = [t2 y2];
end

function s = smallestStep(x)
    deltaX = x(1:end-1,:) - x(2:end,:);
    if (isempty(deltaX)) 
        s = 1e-12;
    else
        s = min(deltaX);
    end
end

function cost = evaluate(point, model1, model2, inputs, options)
    global skorokhodComputeTime;
    modelInput = computeInputs(point, inputs, options.simStep, options.timeHorizon );
    [u1,u2] = computeOutputs(model1, model2, modelInput, options.timeHorizon);
    skoro = tic;
    cost = computeSkorokhodDistanceLUB(u1, u2, options);
    elapsedTime = toc(skoro);
    skorokhodComputeTime = skorokhodComputeTime + elapsedTime;
    cost = -cost; % we are trying to maximize distance
end

function input = computeInputs(point, inputs, simStep, timeHorizon) 
    sampleTimes = 0:simStep:timeHorizon;
    input = zeros(size(sampleTimes,2), length(inputs));
    index = 0;
    for i=1:length(inputs)        
        signalI = point(index+1:index+length(inputs{i}.timePoints));
        timesI = inputs{i}.timePoints;
        interpType = inputs{i}.interpType;
        if (strcmp(interpType,'pconst'))            
            p = @(ts,xs,t) xs(min([find(ts-t>0,1)-1 length(xs)]));
            input(:,i) = transpose(arrayfun(@(t) p(timesI, signalI, t), sampleTimes));
        else
            input(:,i) = transpose(interp1(timesI, signalI, sampleTimes, interpType));
        end
        index = index + length(inputs{i}.timePoints);
    end
    input = [transpose(sampleTimes) input];
end

function [point, lb, ub] = pickRandomInputs(inputs)
    point = []; lb=[]; ub=[];
    for i=1:length(inputs)
        lbI = inputs{i}.lowerBound;
        ubI = inputs{i}.upperBound;
        if (lbI > ubI) 
            fprintf('Warning! Lower bound greater than upper bound. Fixing both bounds to lower bound.\n');
            ubI = lbI;
        end
        pointI = lbI + (ubI-lbI) * rand(1,length(inputs{i}.timePoints));
        point = [pointI point]; %#ok<AGROW>
        lb = [lb repmat(lbI, [1, length(inputs{i}.timePoints)])]; %#ok<AGROW>
        ub = [ub repmat(ubI, [1, length(inputs{i}.timePoints)])]; %#ok<AGROW>
    end
end
