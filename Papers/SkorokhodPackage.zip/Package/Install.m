addpath(genpath('.'));
cd 'cpp'
mex computeSkorokhod.cpp Skorokhod.cpp sCell.cpp free-space-boundary.cpp
cd '../'
fprintf('setup completed.\n');
