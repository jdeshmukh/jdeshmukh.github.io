clc;
clear;
addpath(genpath('../../mex/'));
addpath(genpath('../../cpp/'));

options = struct('timeHorizon', 10, ...
    'simStep', 1e-2, ...
    'numSeeds', 5, ...
    'maxIterations', 20,...
    'maxSimulations', 20,...
    'seed', 0);

SampleTimes = [0.01, 0.05, 0.1, 0.3, 0.5];
% input 1 is pitch command
inputs = {};
inputs{1}.name = 'Desired Theta';  
inputs{1}.timePoints = [0 2 5];
inputs{1}.lowerBound = 0.1;
inputs{1}.upperBound = 0.35;
inputs{1}.interpType = 'pconst';

options.scaleVector = [12.5];   % =~ 1/(0.2*range), range =~ 0.4
options.timeScaleFactor = 2;    % =~ 1/(0.1* timeHorizon)
options.window = 100;
options.delta = 1;

model1 = 'PitchControlLQRContinuous';
model2 = 'PitchControlLQRDiscrete';
window = 100;

for j=1:length(SampleTimes)
    Ts = SampleTimes(j);
    [inp, op1, op2, deltaMax] = maximizeSkorokhodDistanceOverInputs(...
        model1, model2, inputs, options);
    fprintf('For Sample Time = %d, Max Skoro Distance found = %d.\n', Ts, deltaMax);
end