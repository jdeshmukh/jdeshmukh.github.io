clc;
clear;

addpath(genpath('.'));
addpath(genpath('../../mex'));
addpath(genpath('../../cpp'));

fprintf('Initializing model constants.\n');
c1=0.41328;
c2=-0.366;
c3=0.08979;
c4=-0.0337;
c5=0.0001;
c6=2.821;
c7=-0.05231;
c8=0.10299;
c9=-0.00063;
c10=1.0;
c11=14.7;
c12=0.9;
c13=0.05;
c14=0.03;
c15=13.893;
c16=-35.2518;
c17=20.7364;
c18=2.6287;
c19=-1.592;
c20=-2.3421;
c21=2.7799;
c22=-0.3273;
c23=1.0;
c24=1.0;
c25=1.0;
fprintf('Done.\n');

model1 = 'AbstractFuelControlPolynomialEquationsContinuous';
model2 = 'AbstractFuelControlNonPolynomialEquationsContinuous';

options = struct('timeHorizon', 10, ...   % simulation time horizon
                 'simStep', 1e-3, ...     % step used in input signal computation
                 'numSeeds', 100, ...,    % number of restarts for the optimizer
                 'maxSimulations', 3, ... % max number of simulations per iteration
                 'maxIterations', 3, ...  % max number of iterations of optimizer
                 'seed', 3);              % seed for random number generator
            
% input 1 is throttle angle
inputs{1}.name = 'throttle angle (deg)';  
inputs{1}.timePoints = [0 3.5 7 10];
inputs{1}.lowerBound = 0;
inputs{1}.upperBound = (60-8.8);
inputs{1}.interpType = 'pconst';


options.delta = 1;
options.window = 300;
options.timeScaleFactor = 2; % 1 / (0.5)
options.scaleVector = [ 0.68 ]; % 1 / (0.1*14.7)

speeds = [ 1000 1500 2000 ];

for k=1:length(speeds)
    % input 2 is engine speed
    inputs{2}.name = 'engine speed (rpm)';  
    inputs{2}.timePoints = [0 10];
    inputs{2}.lowerBound = speeds(k)-1;
    inputs{2}.upperBound = speeds(k)+1;
    inputs{2}.interpType = 'pconst';
    [inp, op1, op2, deltaMax] = maximizeSkorokhodDistanceOverInputs(model1, model2, inputs, options);
    fprintf('Maximum Skorokhod Distance found for speed %d = %d.\n', speeds(k), deltaMax);
    fprintf('.\n');
end

disp('Finished');

% Uncomment below to see plots of input/outputs
% figure;

% i1 = [inp(:,1) inp(:,2)];
% i2 = [inp(:,1) inp(:,3)];
% 
% hInput1 = subplot(4,1,1);
% colorplot(hInput1, i1);
% 
% hInput2 = subplot(4,1,2);
% colorplot(hInput2, i2);
% 
% hOutput1 = subplot(4,1,3);
% colorplot(hOutput1, op1);
% 
% hOutput2 = subplot(4,1,4);
% colorplot(hOutput2, op2);
% 
