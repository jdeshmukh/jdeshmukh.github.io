clc;
clear;

addpath(genpath('../../mex'));
addpath(genpath('../../cpp'));

options = struct('timeHorizon', 5, ...
    'simStep', 1e-1, ...
    'numSeeds', 30, ...
    'maxSimulations', 20, ...
    'maxIterations', 3, ...
    'seed', 0);

Ki = 0.0723;
Kp = 0.0614;

% input 1 is speed setpoint
inputs = {};
inputs{1}.name = 'speed setpoint';
inputs{1}.timePoints = [0 2 5];
inputs{1}.lowerBound = 2000;
inputs{1}.upperBound = 3000;
inputs{1}.interpType = 'pconst';

options.scaleVector = [0.1];    % ~1/(0.01* range), range = 1000
options.timeScaleFactor = 10;   % this corresponds to a very small time-jitter
                                % permitted 
options.window = 50;
options.delta = 1;
[inp, op1, op2, deltaMax] = ...
     maximizeSkorokhodDistanceOverInputs(...
        'sldemo_enginewc_original', ...
        'sldemo_enginewc_integration_method_changed', ...
        inputs, options);
fprintf('Maximum Skorokhod Distance found = %d.\n', deltaMax);

assignin('base','inp', inp);
assignin('base','output1', op1);
assignin('base','output2', op2);

figure;
plot(op1(:,1),op1(:,2),'-r', 'LineWidth', 1.5);
hold all;
plot(op2(:,1),op2(:,2),'-b', 'LineWidth', 1.5);
