function printTwo(a,b)
    for i=1:length(a)
        fprintf('%10d\t%10d\n', a(i), b(i));
    end
end
