function printThree(a,b,c)
    for i=1:length(a)
         fprintf('%10d\t%10d\t%10d\n', a(i), b(i), c(i));
    end
end