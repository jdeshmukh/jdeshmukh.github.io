clear;
clc;

addpath(genpath('.'));
addpath(genpath('../../mex/'));
addpath(genpath('../../cpp/'));

model1 = 'twoWaterTanks';
model2 = 'twoWaterTanksWithDelay';

TimeHorizon = 100;
StepSize = 5e-2;

% inFlowValues = 6:1:9;
% drainRate1Values = 2:1:5;
% drainRate2Values = 2:1:5;

inFlowValues = 6:1:9;
drainRate1Values = 2:1:5;
drainRate2Values = 2:1:5;


initialLevel1 = 50;
initialLevel2 = 50;
topLevel1 = 100;
topLevel2 = 100;

inputTimes = 0:1:100;
simopts1 = simget(model1);
simopts1 = simset(simopts1, 'FixedStep', StepSize);
simopts2 = simget(model2);
simopts2 = simset(simopts2, 'FixedStep', StepSize);

options.delta = 1;
options.timeScaleFactor = 1;
options.scaleVector = [0.1 0.1];

switchLevel1 = 25;
switchLevel2 = 30;
switchLevel1Delay = 27;
switchLevel2Delay = 32;

delayFactor = 1.0;

windowSizes = [20 40 60 80 100];
numWindows = length(windowSizes);
windowTime = zeros(1,numWindows);
windowLUBcomputations = zeros(1,numWindows);
windowNumMonitorCalls = zeros(1,numWindows);
maxDelta = -inf*ones(1,numWindows);
sumDelta = zeros(1,numWindows);
minDelta = inf*ones(1,numWindows);

for windowNum=1:length(windowSizes)
    deltaArray{windowNum} = [];  %#ok<*SAGROW>
    pointwiseDifference{windowNum} = [];
end
j = 0;
fprintf('Simulating\n');

pwSkMax = -inf;
u1max = [];
u2max = [];

for inFlow=inFlowValues
    for drainRate1=drainRate1Values
        if (drainRate1 > inFlow)
            break;
        end
        for drainRate2=drainRate2Values
            if (drainRate2 > inFlow)
                break;
            end
            drainRate1In = drainRate1*ones(length(inputTimes),1);
            drainRate2In = drainRate2*ones(length(inputTimes),1);
            inFlowIn = inFlow*ones(length(inputTimes),1);
            input = [transpose(inputTimes) drainRate1In drainRate2In inFlowIn];
            [t1, ~, y1] = sim(model1, [0 TimeHorizon], simopts1, input);
            [t2, ~, y2] = sim(model2, [0 TimeHorizon], simopts2, input);
            j = j+1;
            fprintf('.');
            assert(length(t1)==length(t2));
            u1 = [t1 y1];
            u2 = [t2 y2];
            p = zeros(1,size(y1,1));
            for k=1:size(y1,1)
                p(k) = norm(options.scaleVector .* (y1(k,:)-y2(k,:)),2);
            end
            pointwiseDistance = max(p);
            windowNum = 1;
            for window=windowSizes
                options.window = window;
                windowLUBcomputations(windowNum) = windowLUBcomputations(windowNum) + 1;
                tic;
                [delta, n] = computeSkorokhodDistanceLUB(u1,u2,options);
                thisComputationTime = toc;
                pwSkPercent = abs((pointwiseDistance - delta)/pointwiseDistance);
                if (pwSkPercent > pwSkMax) 
                    u1max = u1;
                    u2max = u2;
                    deltaMax = delta;
                    pointwiseMax = pointwiseDistance;
                end
                pointwiseDifference{windowNum} = [pointwiseDifference{windowNum}  (pointwiseDistance - delta)/pointwiseDistance];
                windowNumMonitorCalls(windowNum) = windowNumMonitorCalls(windowNum) + n;
                windowTime(windowNum) = windowTime(windowNum) + thisComputationTime;
                deltaArray{windowNum} = [deltaArray{windowNum} delta];
                if (delta > maxDelta(windowNum))
                    maxDelta(windowNum) = delta;
                end
                if (delta < minDelta(windowNum))
                    minDelta(windowNum) = delta;
                end
                sumDelta(windowNum) = sumDelta(windowNum) + delta;
                windowNum = windowNum + 1;
            end
        end
    end
end
fprintf('\n');
assignin('base','u1max',u1max);
assignin('base','u2max',u2max);
figure;
plot(u1max(:,1), u1max(:,2), '-rx');
hold all;
plot(u2max(:,1), u2max(:,2), '-b');

figure;
figure;
plot(u1max(:,1), u1max(:,3), '-k');
hold all;
plot(u2max(:,1), u2max(:,3), '-csq');


fprintf('=============================================================\n');
fprintf(' Benchmarking results\n');
fprintf('-------------------------------------------------------------\n');
fprintf('Num Simulations = %d\n', j);
fprintf('Window Size\tMax Delta\tMin Delta\n');
printThree(windowSizes,maxDelta,minDelta);
m = zeros(1,numWindows);
for windowNum=1:numWindows
    m(windowNum) = median(deltaArray{windowNum});
end
fprintf('Window Size\tAvg. Delta\tMedian Delta\n');
printThree(windowSizes,sumDelta./windowLUBcomputations,m);
fprintf('Window Size\t Median P-S \tMean P-S\n');
p = zeros(1,numWindows);
q = zeros(1,numWindows);
for windowNum=1:numWindows    
    p(windowNum) = max(pointwiseDifference{windowNum});
    q(windowNum) = std(pointwiseDifference{windowNum});    
end
printThree(windowSizes,p,q);
fprintf('\n-----------------------------------------------------------------------------\n');
fprintf('Window Size\tTime LUB\tTime/Monitor\n'); 
printThree(windowSizes,windowTime/j,windowTime./windowNumMonitorCalls);
fprintf('\n------------------------------------------------------------------------------\n');
fprintf('Window Size\t#Mon Calls\t#Mon Calls/LUB\n');
printThree(windowSizes, windowNumMonitorCalls, windowNumMonitorCalls./windowLUBcomputations);
fprintf('\n===============================================================================\n');

