clc;
clear;
addpath(genpath( <Path to Package/mex> )
addpath(genpath( <Path to Package/cpp> )

options =  struct(...
'timeHorizon',    <Time Horizon for Simulation>  ...
'simStep',        <Sampling frequency for input> ...
'numSeeds',       <Number of random seeds from which optimizer is run> ...
'maxIterations',  <Maximum number of local iterations of optimizer> ...
'maxSimulations', <Maximum number of times cost function is evaluated per iteration> 
'seed',           <Seed for Random Number Generator>);

model1 = <Name of first  Simulink Model. The suffix .mdl or .slx can be omitted.>
model2 = <Name of second Simulink Model. The suffix .mdl or .slx can be omitted.>
numInputs = <Number of inputs to each model. This should be same for both models!>;

inputs = {};
for inputNum=1:numInputs
   % The inputs{} structure defines a finite parameterization of the 
   % inputs to the models. inputs{inputNum}.timePoints is an array 
   % describing a possibly non-uniform set of times (control points)
   % at which the optimizer can pick a value for the input signal. This 
   % value is restricted to the interval defined by:
   % [inputs{inputNum}.lowerBound, inputs{inputNum}.upperBound]
   % The values at intermediate time-points are defined by the
   % interpolation type. Types supported include:
   % o 'pconst' (piecewise constant)
   % o all interpolation types supported by Matlab's interp1 function,
   %   these include 'linear' (piecewise linear).
   % Please note that this is a parameterization of the input! The 
   % meaning assigned to the set of output time-points returned by the
   % Simulink simulator is -always- that these represent vertices of a
   % polygonal trace, or sample-points of a signal that can be obtained 
   % by piecewise linear interpolation
    inputs{inputNum}.timePoints = <Array containing numbres from 0 to options.timeHorizon> ;
    inputs{inputNum}.lowerBound = <Lower bound for input inputNum>
    inputs{inputNum}.upperBound = <Upper bound for input inputNum>
    inputs{inputNum}.interpType = <Interpolation Type>
end


% The intuition for the scaleVector and timeScaleFactor is as follows. 
% Once the signal values are scaled by the scaleVector, and the signal 
% times are scaled by the timeScaleFactory, one unit of perturbation 
% in the value domain is treated as equal to one unit of perturbation 
% in the time domain. 

% One heuristic for picking the timeScaleFactor and scaleVector is as 
% follows: We first pick a timeScaleFactor in such a way that
% one unit of perturbation in the scaled time domain corresponds to the 
% maximum tolerated jitter in the time domain.  Then, we pick a 
% scaleVector to scale up or scale down the signal in a way that 
% tolerating the maximum time jitter is of equal magnitude to 
% tolerating one unit of perturbation in the value domain.

options.scaleVector = <Vector of dimension matching the output>;
options.timeScaleFactor = <Number by which signal times get multiplied>
options.window = <Approx. number of time-points that would lie within a 
                  time-window corresponding to the most tolerated time-
                  jitter>
options.delta =  <This option is to be used for monitoring only. User can
                  set it to 1>;


[inp, op1, op2, deltaMax] = maximizeSkorokhodDistanceOverInputs(model1, model2, inputs, options);
% inp = input, op1 = output of model1, op2 = model2: 
% the tool found maximum Skorokhod distance of deltaMax
% between op1 and op2 when the input inp was applied to 
% model1 and model2 respectively. 

end
