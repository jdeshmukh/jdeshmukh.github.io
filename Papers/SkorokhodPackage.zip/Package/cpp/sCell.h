/*** 
Author: Vinayak Prabhu 
***/

#ifndef GUARD_Cell
#define GUARD_Cell

#include  <utility>
#include <vector>

class sCell {
    double x;
    double y;
    double emin[4]; 
    double emax[4];
public:
    sCell();
    std::vector<double> xpoint1, xpoint2, ypoint1, ypoint2;
    void setCorner(const double & xval, const double & yval);
    std::pair<double, double> getCorner() const; //(x,y)
    void setEdgeMin(const double & val, const int & edge);
    void setEdgeMax(const double & val, const int  & edge);
    void setEdge(const std::pair<double, double> & boundary, const int & edge);
    double getEdgeMin(const int & edge) const;
    double getEdgeMax(const int & edge) const;
    void reachUpdate(const sCell & left_cell, const sCell & bot_cell, const int & mode); 
    void reachUpdateBot(const sCell & bot_cell);
    void reachUpdateLeft(const sCell & left_cell); 
    void intersectWith(const sCell & other);
    void freeSpaceFromVec(const std::vector<double> & px1, 
                          const std::vector<double> & px2, 
                          const std::vector<double> & py1,  
                          const std::vector<double> & py2, 
                          const double & delta);
    void invalidateCell();
    void invalidateEdge(const int & edge);
};

#endif
