/* This is a wrapper for the Skorokhod distance algorithm */

#ifndef _SKOROKHOD
#define _SKOROKHOD

#include "point.h"
#include "sCell.h"
#include "mex.h"

#include <vector>
#include <utility>
#include <algorithm>
#include <functional>
#include <numeric>

using namespace std;


class Skorokhod {
public:
    int window;
    double delta;    
    vector<double> scaleVector;
    timePoint *gdata_x;
    timePoint *gdata_y;
    int gcurr_index;
    std::pair<int,int> gprev_curr;
    sCell * (grows[2]);
    sCell * (gcols[2]);
    Skorokhod(int _window, 
              double _delta, 
              vector<double> _scaleVector);
    void global_init();
    void global_restart();
    ~Skorokhod();
    std::pair<bool, bool> scaleAndMonitor(
                    const timePoint & xval,
                    const timePoint & yval);
private:
    std::pair<bool, bool> monitor(const timePoint &  xval, const timePoint &  yval);
    void update_gprev_curr(pair<int, int> & prev_curr);
    int pIndex_fun(const int & vindex);
    bool edgeValid( const sCell & cell, const int & edge);
    void fill_cell_arr (const int & gcurr_index, 
                    sCell cell_arr[],
                    const timePoint tpoints[],
                    const timePoint & otherTP1,
                    const timePoint & otherTP2,
                    const pair<double, double> & e,
                    const bool & isRow);
};

#endif
