#include "Skorokhod.h"

/* Author: Jyotirmoy Deshmukh
 * Never call this function directly, but through my matlab script wrapper.
 * Reason: I am lazy, and don't want to do argument processing in C/C++,
 * also it is inconvenient and annoying. To see how to call it directly if
 * you have to, look at ComputeSkorokhodDistance.m*/

void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]) {
        std::vector<double> scaleVector;
        std::vector<timePoint> u0;
        std::vector<timePoint> u1;
        const double *s0 = mxGetPr(prhs[0]);
        const double *s1 = mxGetPr(prhs[1]);
        size_t inputSignalDimension = mxGetN(prhs[0]);
        size_t numTimePoints = mxGetM(prhs[0]);
        int window = (int) mxGetScalar(prhs[2]);
        double delta = (double) mxGetScalar(prhs[3]);
        double timeScale = (double) mxGetScalar(prhs[4]);
        scaleVector.push_back(timeScale);
        double *sv = mxGetPr(prhs[5]);
        for (size_t i=0;i<inputSignalDimension; ++i) {
                scaleVector.push_back(sv[i]);
        }

        Skorokhod* w = new Skorokhod(window, 
                                    delta,
                                    scaleVector);
        
        mwSignedIndex dims[2]; 
        dims[0] = numTimePoints;
        dims[1] = 1;
        plhs[0] = mxCreateLogicalArray(2, dims);
        plhs[1] = mxCreateLogicalArray(2, dims);

        bool *status = mxGetLogicals(plhs[0]);
        bool *result = mxGetLogicals(plhs[1]);

        /* I simply hate the way Matlab lays out arrays in mxArray */
        /* [a b 
         *  c d
         *  e f] 
         *  is presented in mxArray as 
         *  [a c e b d f]  */
        for (size_t m=0;m<numTimePoints;++m) {
                timePoint p0;
                timePoint p1;
                for (size_t n=0;n<inputSignalDimension;++n) {
                        if (n==0) {
                                /* first column is time points */
                                p0.time = s0[m];
                                p1.time = s1[m];
                        } else {
                                p0.point.push_back(s0[m + numTimePoints*n]);
                                p1.point.push_back(s1[m + numTimePoints*n]);
                        }
                }
                std::pair<bool,bool> answer = w->scaleAndMonitor(p0, p1);
                status[m] = answer.first;
                result[m] = answer.second;
        }
        delete w;
}
